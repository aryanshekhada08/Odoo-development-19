# -*- coding: utf-8 -*-
{
    'name': "College Erp",
    'version': "1.0",
    'summary': "Simpl ERP  Module",
    'description': "My first Odoo 19 custom module",
    'author': "Aryan",
    'category': "Tools",
    'website': "http://www.example.com",
    'license': 'AGPL-3',
    'sequence': 10,
    'auto_install': True,
    # 'depends': ['base'],
    # 'data': [
    #     'security/ir.model.access.csv',
    #     'views/book_views.xml',
    # ],
    'installable': True,
    'application': True,
    'data': [
        'views/college_student_view.xml',
        'views/College_erp_menu.xml']
}
