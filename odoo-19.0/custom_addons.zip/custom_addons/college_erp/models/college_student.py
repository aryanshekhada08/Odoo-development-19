from odoo import models, fields


class CollegeStudents(models.Model):
    _name = 'college.student'
    _description = 'College Student information'
    admission_date = fields.Date(string='Admission Date', required=True)
    name = fields.Char(string='Name', required=True)
    age = fields.Integer(string='Age')
    enrollment_number = fields.Char(string='Enrollment Number', unique=True)
    course = fields.Char(string='Course')